def hello_text():
    return "This was imported!"
