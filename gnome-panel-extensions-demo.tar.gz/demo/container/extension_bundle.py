import zipfile
import sys
import os
import extension_container_globals
import xml.dom.minidom
import StringIO
class InvalidBundle(StandardError):
    '''
    Used to indicate a bundle is either non-existent or is missing
    a necessary piece.
    '''

class Bundle(object):
    '''
    Bundle is a class to contain a bundle which provides
    methods to allow for easy extraction of files
    from the bundle.
    '''
    def __init__(self, bundleFileName):
        # Check sanity of bundle file        
        if zipfile.is_zipfile(bundleFileName):
            self.bundleFile = zipfile.ZipFile(bundleFileName)

            print bundleFileName

            sys.path.insert(0, os.path.join(extension_container_globals.extension_dir, bundleFileName))
            # Allows us to import python scripts in the bundle file
            # as if they were in a directory
            
            
        else:
           
            print "Sorry, ", bundleFileName, "is not a gnome-extension-bundle file"
            raise InvalidBundle, bundleFileName+"is not a zip file"

        if not self.bundleFile.namelist().count("manifest.xml") == 1:
            print "Raise NOT A BUNDLE exception"
            # Since all bundles must contain manifest.gpem
            raise InvalidBundle, "Bundle does not contain manifest.xml"
        
        

        self.manifest_dom = xml.dom.minidom.parseString(self.bundleFile.read('manifest.xml'))
        bundleFileList = self.manifest_dom.getElementsByTagName('file')

        for fileElement in bundleFileList:
            fileType = fileElement.getAttribute('type')
            
            if fileType == 'main':
                
                try:
                    module_name = fileElement.getAttribute('name').split('.')
                    
                    if module_name[1] == 'py':
                        module_name = module_name[0]
                    else:
                        raise InvalidBundle
                    
                    self.main_module = __import__(module_name)
                    
                    
                    
                except:
                    print "Could not import main module"
                    raise 
        

    def info(self):
        print self.manifest_dom

    def get_extension(self):
        return self.main_module.return_extension()
        

    def open(self, filename):
        return StringIO.StringIO(self.bundleFile.read(filename))

    def open_gtk_image(self, filename):
        pixbuf_l = gtk.gdk.PixbufLoader()

        pixbuf_l.write(self.bundleFile.read(filename))

        pixbuf = pixbuf_l.get_pixbuf()

        pixbuf_l.close()

        image = gtk.Image()

        image.set_from_pixbuf(pixbuf)

        return image

        
