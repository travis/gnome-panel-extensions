from os.path import expandvars

extension_dir = expandvars("$HOME/.panelextensions/")
